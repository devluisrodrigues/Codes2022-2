# Codes2022-2
Esse repositório contém os arquivos referentes ao projeto de Co-design de aplicaitvos da turma de 2022-2.
Assim, visa desenvolver a versão html do app idealizado em aula.

## Referências	
- https://www.flaticon.com/
- https://validator.w3.org/
- https://netflix.com/
- https://www.disneyplus.com/